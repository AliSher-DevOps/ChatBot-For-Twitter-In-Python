from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options

chromeOptions = Options()
chromeOptions.add_argument("--start-maximized")
driver = webdriver.Chrome(executable_path="Chatbot/chromedriver.exe", options=chromeOptions)
tweeter_url = "https://twitter.com/login"
driver.get(tweeter_url)
wait = WebDriverWait(driver, 10)
