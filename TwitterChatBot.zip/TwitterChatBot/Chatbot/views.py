from django.shortcuts import render
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as ec
from transformers import pipeline
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as ec

from transformers import pipeline
from Chatbot import wait, driver


def main_menu(request):
    return render(request, 'login.html')


def connection(request):
    username_input = wait.until(ec.visibility_of_element_located((By.NAME, "session[username_or_email]")))
    username_input.send_keys("Muhamma42947069")
    password_input = wait.until(ec.visibility_of_element_located((By.NAME, "session[password]")))
    password_input.send_keys("Machu1481")
    login_button = wait.until(
        ec.visibility_of_element_located((By.XPATH, "//div[@data-testid='LoginForm_Login_Button']")))
    login_button.click()
    return render(request, 'ChatBotUI.html')


def home(request):
    if request.POST:
        username = request.POST['username']
        search_input = driver.find_element_by_xpath("//div/input[@data-testid='SearchBox_Search_Input']")
        driver.find_element_by_xpath("//div/input[@data-testid='SearchBox_Search_Input']").clear()
        search_input.send_keys(username + Keys.ENTER)
    return render(request, 'loading.html')


def get_data(request):
    tweet_divs = driver.find_elements_by_xpath("//div[@data-testid='tweet']")
    tweets = []
    times = []
    for div in tweet_divs:
        spans = div.find_elements_by_xpath(".//div/span")
        for span in spans:
            tweets.append(span.text)
        time = div.find_elements_by_xpath(".//div/a/time")
        for span in time:
            times.append(span.text)
    name = tweets[0]
    user_account_name = tweets[1]
    tweet = tweets[3]
    reply = tweets[4]
    re_tweet = tweets[5]
    like = tweets[6]
    hours = times[0]
    auto_reply = get_tweet_and_generate_reply(tweet)
    post_reply(auto_reply)
    content = {"name": name, "user_account_name": user_account_name, "tweet": tweet, "reply": reply,
               "re_tweet": re_tweet, "like": like, "time": hours, "auto_reply": auto_reply}

    return render(request, 'statistics.html', content)


def get_tweet_and_generate_reply(tweet):
    text_generator = pipeline("text-generation")
    seedtext = tweet
    text = text_generator(seedtext, max_length=240, do_sample=True, top_p=0.95, top_k=60)
    # print(text[0]["generated_text"])
    reply_text = text[0]["generated_text"]
    reply_text2 = reply_text.split("\n\n")
    if reply_text2[0] == seedtext:
        reply_text2[0] = reply_text2[1]
    rep_text = reply_text2[0].strip(seedtext)
    return rep_text


def post_reply(auto_reply):
    tweet_button = wait.until(ec.visibility_of_element_located((By.XPATH, "//div[@data-testid='tweet']")))
    tweet_button.click()
    tweet_button2 = wait.until(ec.visibility_of_element_located((By.XPATH, "//div[@data-testid='reply']")))
    tweet_button2.click()
    tweet_reply_area = driver.find_element_by_xpath("//div/div[@data-testid='tweetTextarea_0']")
    tweet_reply_area.send_keys(auto_reply)
    tweet_reply = wait.until(ec.visibility_of_element_located((By.XPATH, "//div/div[@data-testid='tweetButton']")))
    tweet_reply.click()


def reply_to_mentions(request):
    notification = wait.until(
        ec.visibility_of_element_located((By.XPATH, "//div/nav/a[@data-testid='AppTabBar_Notifications_Link']")))
    notification.click()
    mention = wait.until(ec.visibility_of_element_located(
        (By.XPATH, "//div/a/div[@class='css-901oao r-m0bqgq r-1qd0xha r-a023e6 r-b88u0q r-ad9z0x r-bcqeeo r-qvutc0']")))
    mention.click()
    mention_id = wait.until(ec.visibility_of_element_located((By.XPATH, "//div[@data-testid='tweet']")))
    mention_id.click()
    mention_rep = wait.until(ec.visibility_of_element_located(
        (By.XPATH, "//div[@class='css-1dbjc4n r-18u37iz r-1h0z5md r-3qxfft r-s1qlax r-rjfia']")))
    mention_rep.click()
    tweet_divs = driver.find_elements_by_xpath("//div[@data-testid='tweet']")
    tweets = []
    times = []
    for div in tweet_divs:
        spans = div.find_elements_by_xpath(".//div/span")
        for span in spans:
            tweets.append(span.text)
        time = div.find_elements_by_xpath(".//div/a/time")
        for span in time:
            times.append(span.text)
    name = tweets[0]
    user_account_name = tweets[1]
    tweet = tweets[3]
    reply = tweets[4]
    re_tweet = tweets[5]
    like = tweets[6]
    hours = times[0]
    text_generator = pipeline("text-generation")
    seedtext = tweet
    text = text_generator(seedtext, max_length=240, do_sample=True, top_p=0.95, top_k=60)
    # print(text[0]["generated_text"])
    reply_text = text[0]["generated_text"]
    reply_text2 = reply_text.split("\n\n")
    if reply_text2[0] == seedtext:
        reply_text2[0] = reply_text2[1]
    rep_text = reply_text2[0].strip(seedtext)
    tweet_reply_area = driver.find_element_by_xpath("//div/div[@data-testid='tweetTextarea_0']")
    tweet_reply_area.send_keys(rep_text)
    tweet_reply = wait.until(ec.visibility_of_element_located((By.XPATH, "//div/div[@data-testid='tweetButton']")))
    tweet_reply.click()
    content = {"name": name, "user_account_name": user_account_name, "tweet": tweet, "reply": reply,
               "re_tweet": re_tweet, "like": like, "time": hours, "auto_reply": rep_text}
    return render(request, 'statistics.html', content)
